#ifndef CHARACTERIZE_SERVO_TEST_H
#define CHARACTERIZE_SERVO_TEST_H

// Function to characterize the servo
void characterize_servo_test();

#endif // CHARACTERIZE_SERVO_TEST_H

#ifndef ORIENTATION_TEST_H
#define ORIENTATION_TEST_H

void orientation_test();
void orientation_test2();

#endif // ORIENTATION_TEST_H
